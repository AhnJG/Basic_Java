//import Apkg.A1class;
import Apkg.*;
import Bpkg.Bclass;

public class test {

	public static void main(String[] args) {
		Aclass a = new Aclass();
		a.name="aaa";
		a.show();
		
		Bclass b = new Bclass();
		b.age = 10;
		b.show();
		
		A1class a1 = new A1class();
		a1.name="aaa";
		a1.showName();
	}

}
