package Apkg;

public class A1class extends Aclass{
	public void showName()
	{
		System.out.println("�̸���"+name);
	}
}
