package Bpkg;

public class Bclass {
	public int age;
	public void show()
	{
		System.out.println("Bpkg_show");
	}
}
