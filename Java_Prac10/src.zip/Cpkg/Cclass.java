package Cpkg;

public class Cclass {
	protected void show()
	{
		System.out.println("Cpkg");
	}
}
